// Worker code can be anything you want.
console.log("Hello from IronWorker!")

// When you're ready press '▶ Run code ...'
  
